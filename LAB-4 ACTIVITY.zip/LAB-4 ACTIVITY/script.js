// --- AUTHENTICATION ---

// Step 1: Login function using the Backend API
async function login(username, password) {
    try {
        const response = await fetch('http://localhost:3000/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            // Save the JWT token for session persistence
            sessionStorage.setItem('authToken', data.token);
            alert('Login successful!');
            
            // Render the UI based on the user object returned by the server 
            showDashboard(data.user);
        } else {
            alert('Login failed: ' + data.error); 
        }
    } catch (err) {
        alert('Network error: ' + err.message); 
    }
}

// Step 2: Helper to attach the Authorization header 
function getAuthHeader() {
    const token = sessionStorage.getItem('authToken'); 
    return token ? { 'Authorization': `Bearer ${token}` } : {}; 
}

// --- PROTECTED DATA FETCHING ---

// Step 3: Fetching admin-only data 
async function loadAdminDashboard() {
    try {
        const res = await fetch('http://localhost:3000/api/admin/dashboard', {
            headers: getAuthHeader() // Includes the Bearer token 
        });

        const data = await res.json(); 

        if (res.ok) {
            document.getElementById('content').innerText = data.message; 
        } else {
            document.getElementById('content').innerText = 'Access denied!'; 
        }
    } catch (err) {
        console.error('Error:', err);
    }
}

// --- LOGOUT ---

function logout() {
    // Clear the token to end the session [cite: 357, 365]
    sessionStorage.removeItem('authToken');
    location.reload(); 
}