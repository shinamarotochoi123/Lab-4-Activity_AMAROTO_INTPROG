// State & Storage Keys
let currentUser = null;
const API_URL = 'http://localhost:6767';
const STORAGE_KEY = 'ipt_demo_v1';
window.db = { accounts: [], departments: [], employees: [], requests: [] };

// --- Initialize App ---
function init() {
    loadFromStorage();
    window.addEventListener('hashchange', handleRouting);

    // Check if JWT token exists in sessionStorage (backend auth)
    const token = sessionStorage.getItem('auth_token');
    const savedUser = sessionStorage.getItem('current_user');

    if (token && savedUser) {
        const user = JSON.parse(savedUser);
        setAuthState(true, user);
    }

    if (!window.location.hash) window.location.hash = '#/';
    handleRouting();
}

// --- Routing Logic ---
function handleRouting() {
    const hash = window.location.hash || '#/';
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));

    const routeMap = {
        '#/': 'home-page',
        '#/login': 'login-page',
        '#/register': 'register-page',
        '#/profile': 'profile-page',
        '#/verify-email': 'verify-page',
        '#/employees': 'employees-page',
        '#/accounts': 'accounts-page',
        '#/departments': 'departments-page',
        '#/requests': 'requests-page'
    };

    const targetId = routeMap[hash] || 'home-page';
    const targetPage = document.getElementById(targetId);
    if (targetPage) {
        targetPage.classList.add('active');
        renderAdminTables();
        renderRequests();
    }
}

// --- Auth State Management ---
function setAuthState(isAuth, user = null) {
    currentUser = user;
    const body = document.body;
    if (isAuth) {
        body.classList.add('authenticated');
        body.classList.remove('not-authenticated');
        document.getElementById('nav-username').textContent = user.firstName;
        if (user.role === 'Admin') body.classList.add('is-admin');

        document.getElementById('profile-name').textContent = `${user.firstName} ${user.lastName}`;
        document.getElementById('profile-email').textContent = user.email;
        document.getElementById('profile-role').textContent = user.role;
    } else {
        body.classList.remove('authenticated', 'is-admin');
        body.classList.add('not-authenticated');
        // Clear both sessionStorage items on logout
        sessionStorage.removeItem('auth_token');
        sessionStorage.removeItem('current_user');
    }
}

// --- Storage Persistence (for local db: employees, departments, requests) ---
function loadFromStorage() {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
        window.db = JSON.parse(data);
    } else {
        saveToStorage();
    }
}

function saveToStorage() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(window.db));
}

// --- LOGIN FORM (Now uses backend API + JWT) ---
document.getElementById('login-form').onsubmit = async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const pass = document.getElementById('login-password').value;

    try {
        const response = await fetch(`${API_URL}/api/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: email, password: pass })
        });

        const data = await response.json();

        if (response.ok) {
            // Save JWT token and user info in sessionStorage
            sessionStorage.setItem('auth_token', data.token);
            sessionStorage.setItem('current_user', JSON.stringify(data.user));

            setAuthState(true, data.user);
            window.location.hash = '#/profile';
        } else {
            alert(data.error || 'Invalid credentials.');
        }
    } catch (err) {
        alert('Cannot connect to server. Make sure the backend is running on port 6767.');
        console.error(err);
    }
};

// --- REGISTER FORM (still local for Lab 4 scope) ---
document.getElementById('register-form').onsubmit = (e) => {
    e.preventDefault();
    const emailValue = document.getElementById('reg-email').value;
    const newUser = {
        firstName: document.getElementById('reg-fname').value,
        lastName: document.getElementById('reg-lname').value,
        email: emailValue,
        password: document.getElementById('reg-pass').value,
        role: 'User',
        verified: false
    };
    window.db.accounts.push(newUser);
    saveToStorage();
    const displayEmail = document.getElementById('verify-email-display');
    if (displayEmail) displayEmail.textContent = emailValue;
    window.location.hash = '#/verify-email';
};

// --- Simulate Email Verification ---
const simulateBtn = document.getElementById('simulate-verify-btn');
if (simulateBtn) {
    simulateBtn.onclick = () => {
        const lastUser = window.db.accounts[window.db.accounts.length - 1];
        if (lastUser) {
            lastUser.verified = true;
            saveToStorage();
            alert("Success! Your email is now verified. You can now log in.");
            window.location.hash = '#/login';
        }
    };
}

// --- LOGOUT ---
document.getElementById('logout-btn').onclick = () => {
    setAuthState(false);
    window.location.hash = '#/';
};

// --- Admin Rendering Logic ---
function renderAdminTables() {
    const empList = document.getElementById('employees-list');
    if (empList) {
        empList.innerHTML = window.db.employees.length ? window.db.employees.map(emp => `
            <tr>
                <td>${emp.id}</td>
                <td>${emp.name}</td>
                <td>${emp.position}</td>
                <td>${emp.dept}</td>
                <td>
                    <button class="btn btn-outline-danger btn-sm" onclick="deleteItem('employee', '${emp.id}')">Delete</button>
                </td>
            </tr>
        `).join('') : '<tr><td colspan="5" class="text-center">No employees found.</td></tr>';
    }

    const accountList = document.getElementById('accounts-list');
    if (accountList) {
        accountList.innerHTML = window.db.accounts.map(acc => `
            <tr>
                <td>${acc.firstName} ${acc.lastName}</td>
                <td>${acc.email}</td>
                <td>${acc.role}</td>
                <td>${acc.verified ? '✅' : '❌'}</td>
                <td>
                    <button class="btn btn-outline-primary btn-sm" onclick="editAccount('${acc.email}')">Edit</button>
                    <button class="btn btn-outline-danger btn-sm" onclick="deleteItem('account', '${acc.email}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }

    const deptList = document.getElementById('departments-list');
    if (deptList) {
        deptList.innerHTML = window.db.departments.length ? window.db.departments.map(d => `
            <tr>
                <td>${d.name}</td>
                <td>${d.description}</td>
                <td><button class="btn btn-outline-danger btn-sm" onclick="deleteItem('department', '${d.name}')">Delete</button></td>
            </tr>
        `).join('') : '<tr><td colspan="3" class="text-center">No departments.</td></tr>';
    }

    const empDeptSelect = document.getElementById('emp-dept');
    if (empDeptSelect) {
        empDeptSelect.innerHTML = window.db.departments.map(d =>
            `<option value="${d.name}">${d.name}</option>`
        ).join('') || '<option>Engineering</option>';
    }
}

// --- Department Management ---
const addDeptBtn = document.getElementById('add-dept-btn');
const deptFormContainer = document.getElementById('dept-form-container');
const deptForm = document.getElementById('department-manage-form');

if (addDeptBtn) {
    addDeptBtn.onclick = () => {
        deptFormContainer.classList.remove('d-none');
        deptForm.reset();
    };
}

if (deptForm) {
    deptForm.onsubmit = (e) => {
        e.preventDefault();
        window.db.departments.push({
            name: document.getElementById('manage-dept-name').value,
            description: document.getElementById('manage-dept-desc').value
        });
        saveToStorage();
        renderAdminTables();
        deptFormContainer.classList.add('d-none');
    };
}

document.getElementById('cancel-dept-btn').onclick = () => deptFormContainer.classList.add('d-none');

// --- Employee Management ---
const employeeForm = document.getElementById('employee-form');
if (employeeForm) {
    employeeForm.onsubmit = (e) => {
        e.preventDefault();
        const email = document.getElementById('emp-email').value;
        const account = window.db.accounts.find(acc => acc.email === email);

        window.db.employees.push({
            id: document.getElementById('emp-id').value,
            email: email,
            position: document.getElementById('emp-pos').value,
            dept: document.getElementById('emp-dept').value,
            name: account ? `${account.firstName} ${account.lastName}` : "Unknown User"
        });
        saveToStorage();
        renderAdminTables();
        employeeForm.reset();
    };
}

// --- Account Management ---
window.editAccount = (email) => {
    const acc = window.db.accounts.find(a => a.email === email);
    if (acc) {
        document.getElementById('manage-fname').value = acc.firstName;
        document.getElementById('manage-lname').value = acc.lastName;
        document.getElementById('manage-email').value = acc.email;
        document.getElementById('manage-role').value = acc.role;
        document.getElementById('manage-verified').checked = acc.verified;
        document.getElementById('account-form-container').classList.remove('d-none');
    }
};

// --- Request Management ---
const itemRowsContainer = document.getElementById('item-rows');
const addItemBtn = document.querySelector('#requestModal .btn-outline-primary');
const requestModalEl = document.getElementById('requestModal');

function addItemRow() {
    const row = document.createElement('div');
    row.className = 'd-flex gap-2 mb-2 request-item-row';
    row.innerHTML = `
        <input type="text" class="form-control item-name-field" placeholder="Item name">
        <input type="number" class="form-control w-25 item-qty-field" value="1" min="1">
        <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.parentElement.remove()">x</button>
    `;
    itemRowsContainer.appendChild(row);
}

if (requestModalEl) {
    requestModalEl.addEventListener('show.bs.modal', () => {
        itemRowsContainer.innerHTML = '';
        for (let i = 0; i < 4; i++) {
            addItemRow();
        }
    });
}

if (addItemBtn) {
    addItemBtn.onclick = () => addItemRow();
}

document.getElementById('request-form').onsubmit = (e) => {
    e.preventDefault();
    const items = [];
    const rows = document.querySelectorAll('.request-item-row');

    rows.forEach(row => {
        const nameInput = row.querySelector('.item-name-field');
        const qtyInput = row.querySelector('.item-qty-field');
        const nameValue = nameInput.value.trim();
        if (nameValue !== "") {
            items.push(`${qtyInput.value}x ${nameValue}`);
        }
    });

    if (items.length === 0) {
        alert("Please enter at least one item.");
        return;
    }

    window.db.requests.push({
        type: document.querySelector('#requestModal select').value,
        status: 'Pending',
        date: new Date().toLocaleDateString(),
        details: items.join(', ')
    });

    saveToStorage();

    const modalInstance = bootstrap.Modal.getInstance(requestModalEl);
    if (modalInstance) modalInstance.hide();

    renderRequests();
};

function renderRequests() {
    const list = document.getElementById('requests-list');
    const table = document.getElementById('requests-table');
    const empty = document.getElementById('requests-empty');
    if (!list) return;

    if (window.db.requests.length > 0) {
        empty.classList.add('d-none');
        table.classList.remove('d-none');
        list.innerHTML = window.db.requests.map(req => `
            <tr>
                <td><strong>${req.type}</strong><br><small class="text-muted">${req.details}</small></td>
                <td><span class="badge bg-warning text-dark">${req.status}</span></td>
                <td>${req.date}</td>
            </tr>
        `).join('');
    } else {
        empty.classList.remove('d-none');
        table.classList.add('d-none');
    }
}

// --- Global Delete ---
window.deleteItem = (type, identifier) => {
    if (!confirm(`Delete this ${type}?`)) return;
    if (type === 'account') window.db.accounts = window.db.accounts.filter(a => a.email !== identifier);
    if (type === 'employee') window.db.employees = window.db.employees.filter(e => e.id !== identifier);
    if (type === 'department') window.db.departments = window.db.departments.filter(d => d.name !== identifier);
    saveToStorage();
    renderAdminTables();
};

init();