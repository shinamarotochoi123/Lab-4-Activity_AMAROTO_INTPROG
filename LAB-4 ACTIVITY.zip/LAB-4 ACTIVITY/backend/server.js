const express = require("express");
const path = require("path");
const cors = require("cors");
const app = express();
const PORT = 6767; 

app.use(express.json());
app.use(cors());

// Serves your index.html/style.css/script.js from the root folder
app.use(express.static(path.join(__dirname, "../"))); 

// --- PROFESSOR'S DEFAULT CREDENTIALS ---
const users = [
    { 
        username: 'admin123@example.com', 
        password: 'Password123!', 
        firstName: 'User', 
        lastName: 'Admin', 
        role: 'Admin' 
    }
];

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        res.json({
            token: 'valid-jwt-token',
            user: { firstName: user.firstName, lastName: user.lastName, email: user.username, role: user.role }
        });
    } else {
        res.status(401).json({ error: 'Invalid credentials' });
    }
});

app.listen(PORT, () => {
    console.log(`Backend Server running on http://localhost:${PORT}`);
})